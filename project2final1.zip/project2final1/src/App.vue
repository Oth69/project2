<template>
<div>
    <Signup/>
     <div>
    <router-view></router-view>
    <div class="section">
      <div class="container">
        <simple-upload/>
  </div>
    </div>

</template>
<script>
import Signup from './components/Signup';

import SimpleUpload from '.components/SimpleUpload';

export default{
    name: 'App',
    components:{
        Signup,
        SimpleUpload
    }
  




}
</script>


}
</script>
